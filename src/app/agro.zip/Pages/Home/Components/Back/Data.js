
const data ={
    productItems:[
        {
            id: "1",
            name: "Tomatoes",
            price: 15,
            image: "../../../../assets/Tomato.png"
        },
        {
            id: "2",
            name: "carrots",
            price: 20,
            image: "../../../../assets/carrot.png"
        },
        {
            id: "3",
            name: "onions",
            price: 40,
            image: "../../../../assets/onions.png"
        },
        {
            id: "4",
            name: "spinach",
            price: 10,
            image: "../../../../assets/spinach.png"
        },
        {
            id: "5",
            name: "Grapes",
            price: 25,
            image: "../../../../assets/grapes.png"
        },
        {
            id: "6",
            name: "Garlic",
            price: 40,
            image: "../../../../assets/garlic.png"
        },

    ]
}

export default data;