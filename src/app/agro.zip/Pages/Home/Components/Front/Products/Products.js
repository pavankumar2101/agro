import React from 'react'

const Products = () => {
  return (
    <div>List of products</div>
  )
}

export default Products