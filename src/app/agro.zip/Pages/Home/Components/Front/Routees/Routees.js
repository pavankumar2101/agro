// import React from 'react';
// import {BrowserRouter as Router,Routes, Route} from "react-router-dom";
// import Products from "../Products/Products";

// const Routees = () => {
//   return (
//     <div>
//       <Router>
//       <Routes>
//         <Route path="/" exact>
//          <Products/>
//         </Route>
//       </Routes>
//       </Router>
      
//     </div>
//   )
// }

// export default Routees;