import React from 'react'

const Products = () => {
  return (
    <div className="products">
      <h5>Agriculture Products</h5>
      <h5>Projects Completed</h5>
      <h5>Satisfied Clients</h5>
      <h5>Experts Farmers</h5>
    
    </div>
  )
}

export default Products