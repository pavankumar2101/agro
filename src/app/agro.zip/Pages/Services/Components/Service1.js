import React from 'react'
import Frame2 from "../../../assets/Frame2.png"
const Service1 = () => {
  return (
    
    <section className='service1'>
        <img src={Frame2} alt="" />
    </section>
    
  )
}

export default Service1