import React from 'react'

const Model3 = () => {
  return (
    <section className='model3'>
        <p>Agriculture Products</p>
        <p>Projects Completed</p>
        <p>Satisfied Clients</p>
        <p>Experts Farmers</p>
    </section>
  )
}

export default Model3