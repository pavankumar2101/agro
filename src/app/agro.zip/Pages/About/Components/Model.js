import React from "react";
import Frame from "../../../assets/Frame.png";


const Model = () => {
  return (
    <>
      <section className="model">
        <div className="bg-img">
          <img src={Frame} alt="" />
        </div>
      </section>
    </>
  );
};

export default Model;




